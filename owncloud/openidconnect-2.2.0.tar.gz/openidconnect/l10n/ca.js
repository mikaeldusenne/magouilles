OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Només els convidats es poden autentificar a través d'aquest mecanisme"
},
"nplurals=2; plural=(n != 1);");
