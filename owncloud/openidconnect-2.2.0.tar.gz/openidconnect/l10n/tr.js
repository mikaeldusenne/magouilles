OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Bu kimlik doğrulama mekanizması aracılığıyla yalnızca misafirlere izin verilir"
},
"nplurals=2; plural=(n > 1);");
