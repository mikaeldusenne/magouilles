OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Solo los invitados pueden usar este mecanismo de autentificación"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
