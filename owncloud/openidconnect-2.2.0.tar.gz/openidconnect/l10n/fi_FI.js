OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Vain vieraat on sallittu tämän tunnistusmenetelmän kautta"
},
"nplurals=2; plural=(n != 1);");
