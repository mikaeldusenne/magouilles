OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Чрез този механизъм за удостоверяване се допускат само гости"
},
"nplurals=2; plural=(n != 1);");
