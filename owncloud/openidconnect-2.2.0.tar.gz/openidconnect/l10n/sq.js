OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Përmes këtij mekanizmi mirëfilltësimi lejohen vetëm mysafirët"
},
"nplurals=2; plural=(n != 1);");
