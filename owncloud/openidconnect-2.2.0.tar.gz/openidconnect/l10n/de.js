OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Nur Gäste werden durch diesen Authentifizierungsmechanismus zugelassen"
},
"nplurals=2; plural=(n != 1);");
