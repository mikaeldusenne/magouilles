OC.L10N.register(
    "openidconnect",
    {
    "Only guests are allowed through this authentication mechanism" : "Uniquement les invités sont autorisés via ce système d'authentification"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
